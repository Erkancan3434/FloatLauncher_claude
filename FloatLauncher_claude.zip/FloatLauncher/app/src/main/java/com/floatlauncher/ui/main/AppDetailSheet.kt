package com.floatlauncher.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawable.toBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.floatlauncher.R
import com.floatlauncher.data.model.AppInfo
import com.floatlauncher.ui.theme.AccentBlue
import com.floatlauncher.util.DeviceCapabilityUtils

/**
 * Bir uygulama seçildiğinde açılan detay/aksiyon sayfası.
 * Cihazın gerçek yeteneğine göre buton metni ve davranışı değişir:
 *  - Native freeform destekleniyorsa → doğrudan serbest-form pencerede başlatır.
 *  - Sadece üretici desteği varsa → kullanıcıyı bilgilendirip üretici ayarına yönlendirir.
 *  - Hiçbiri yoksa → normal başlatma sunulur, buton metni buna göre değişir.
 */
@Composable
fun AppDetailContent(
    app: AppInfo,
    capability: DeviceCapabilityUtils.FloatingCapability,
    onFavoriteToggle: () -> Unit,
    onLaunchFloating: () -> Unit,
    onLaunchNormal: () -> Unit,
    onOpenManufacturerSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val bitmap = remember(app.packageName) {
                app.icon?.toBitmap(width = 160, height = 160)?.asImageBitmap()
            }
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(AccentBlue.copy(alpha = 0.25f))
            ) {
                if (bitmap != null) {
                    androidx.compose.foundation.Image(
                        bitmap = bitmap,
                        contentDescription = app.label,
                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                    )
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(app.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    app.versionName?.let { "v$it" } ?: app.packageName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onFavoriteToggle) {
                Icon(
                    imageVector = if (app.isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = null,
                    tint = AccentBlue
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        when (capability) {
            DeviceCapabilityUtils.FloatingCapability.NATIVE_FREEFORM -> {
                Button(
                    onClick = onLaunchFloating,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                ) {
                    Icon(Icons.Filled.PictureInPicture, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResourceCompat(R.string.launch_in_floating_window))
                }
            }

            DeviceCapabilityUtils.FloatingCapability.MANUFACTURER_SPECIFIC -> {
                Text(
                    "Bu cihazda genel bir kayan pencere API'si yok, ancak üreticinizin " +
                        "kendi çoklu pencere/pop-up özelliği olabilir.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onOpenManufacturerSettings,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(stringResourceCompat(R.string.open_manufacturer_settings))
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onLaunchNormal,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Filled.OpenInNew, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResourceCompat(R.string.launch_normal))
                }
            }

            DeviceCapabilityUtils.FloatingCapability.UNSUPPORTED -> {
                Text(
                    stringResourceCompat(R.string.floating_not_supported_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onLaunchNormal,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Filled.OpenInNew, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResourceCompat(R.string.launch_normal))
                }
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun stringResourceCompat(id: Int): String = androidx.compose.ui.res.stringResource(id)
