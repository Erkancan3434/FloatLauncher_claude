package com.floatlauncher.service

import android.app.ActivityOptions
import android.content.Context
import android.graphics.Rect
import android.os.Build
import com.floatlauncher.util.DeviceCapabilityUtils

/**
 * Kullanıcının seçtiği uygulamayı, cihazın gerçekten desteklediği yöntemle
 * başlatmaktan sorumludur.
 *
 * Bu sınıf HİÇBİR ZAMAN:
 *  - hedef APK'yı kopyalamaz veya yeniden paketlemez,
 *  - hedef uygulamanın verisini/işlem alanını sanallaştırmaz,
 *  - kök (root) erişimi veya gizli/dokümante edilmemiş sistem API'leri kullanmaz.
 *
 * Sadece iki resmi yol kullanılır:
 *  1) `ActivityOptions.setLaunchBounds(Rect)` ile serbest-form (freeform)
 *     pencere ipucu — SADECE cihaz `FEATURE_FREEFORM_WINDOW_MANAGEMENT`
 *     destekliyorsa etkilidir.
 *  2) Standart `Intent.FLAG_ACTIVITY_NEW_TASK` ile normal başlatma — freeform
 *     desteklenmiyorsa bilgilendirilmiş bir şekilde buna düşülür.
 */
sealed class LaunchResult {
    data object FreeformLaunched : LaunchResult()
    data object NormalLaunched : LaunchResult()
    data class Failed(val reason: String) : LaunchResult()
    data object UnsupportedRedirectToSettings : LaunchResult()
}

class FloatingWindowManager(private val context: Context) {

    /**
     * [packageName] uygulamasını, mümkünse serbest-form bir pencerede,
     * değilse normal şekilde başlatır.
     *
     * @param bounds Freeform destekleniyorsa penceğin ekran üzerindeki
     *   hedef sınırları (piksel). Null ise makul bir varsayılan (ekranın
     *   ortasında, %70 boyutunda) kullanılır.
     */
    fun launch(packageName: String, bounds: Rect? = null): LaunchResult {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return LaunchResult.Failed("Bu uygulama için başlatma Intent'i bulunamadı.")

        val capability = DeviceCapabilityUtils.detectFloatingCapability(context)

        return when (capability) {
            DeviceCapabilityUtils.FloatingCapability.NATIVE_FREEFORM -> {
                try {
                    val targetBounds = bounds ?: defaultBounds()
                    val options = ActivityOptions.makeBasic().apply {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            launchBounds = targetBounds
                        }
                    }
                    launchIntent.addFlags(
                        android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                            android.content.Intent.FLAG_ACTIVITY_MULTIPLE_TASK
                    )
                    context.startActivity(launchIntent, options.toBundle())
                    LaunchResult.FreeformLaunched
                } catch (e: Exception) {
                    // Freeform denemesi başarısız olursa normal başlatmaya düş —
                    // kullanıcı en azından uygulamayı açabilsin, uygulama çökmesin.
                    fallbackNormalLaunch(launchIntent)
                }
            }

            DeviceCapabilityUtils.FloatingCapability.MANUFACTURER_SPECIFIC -> {
                // Üreticiye özgü gerçek bir "pop-up başlatma" API'si genel
                // geliştiricilere açık değildir. Dürüst davranıp kullanıcıyı
                // üreticinin kendi çoklu pencere özelliğine yönlendiriyoruz;
                // burada normal başlatma yapıp kullanıcıyı bilgilendirmek en
                // doğru ve şeffaf yaklaşımdır.
                fallbackNormalLaunch(launchIntent)
                LaunchResult.UnsupportedRedirectToSettings
            }

            DeviceCapabilityUtils.FloatingCapability.UNSUPPORTED -> {
                LaunchResult.UnsupportedRedirectToSettings
            }
        }
    }

    private fun fallbackNormalLaunch(intent: android.content.Intent): LaunchResult {
        return try {
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LaunchResult.NormalLaunched
        } catch (e: Exception) {
            LaunchResult.Failed(e.message ?: "Uygulama başlatılamadı.")
        }
    }

    /** Ekranın ortasında, genişliğin/yüksekliğin ~%70'ini kaplayan varsayılan pencere. */
    private fun defaultBounds(): Rect {
        val displayMetrics = context.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels
        val width = (screenWidth * 0.7f).toInt()
        val height = (screenHeight * 0.7f).toInt()
        val left = (screenWidth - width) / 2
        val top = (screenHeight - height) / 2
        return Rect(left, top, left + width, top + height)
    }
}
