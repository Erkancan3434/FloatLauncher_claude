package com.floatlauncher.ui.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.floatlauncher.util.PermissionUtils

/**
 * Uygulamanın çalışması için gereken izinlerin anlık, salt-okunur bir
 * görüntüsü. Compose tarafında her `onResume` sonrası yeniden hesaplanır
 * (kullanıcı Ayarlar'dan dönünce durum otomatik güncellenir).
 */
data class PermissionsState(
    val hasOverlay: Boolean,
    val hasNotifications: Boolean,
    val hasAccessibility: Boolean
) {
    /** Uygulamanın çekirdek işlevi (listeleme + başlatma) için ZORUNLU olan izinler tamam mı? */
    val hasRequiredPermissions: Boolean get() = hasOverlay && hasNotifications

    companion object {
        fun from(context: Context): PermissionsState {
            val hasNotif = if (PermissionUtils.requiresNotificationPermission()) {
                ContextCompat.checkSelfPermission(
                    context, Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true // Android 13 altında çalışma zamanı izni gerekmez.
            }

            return PermissionsState(
                hasOverlay = PermissionUtils.hasOverlayPermission(context),
                hasNotifications = hasNotif,
                hasAccessibility = PermissionUtils.isAccessibilityServiceEnabled(context)
            )
        }
    }
}
