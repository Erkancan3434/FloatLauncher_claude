# AIDE Derleme Ayarları (Android 10 / API 29 için)

E�er hâlâ "aapt failed" veya "Paket ayrıştırılamadı" hatası alıyorsan, AIDE'nin deneysel fonksiyonlar menüsünde aşağıdaki ayarları kontrol et:

## Açık Olması Gerekenler (✓)

1. **Experimental Functions → D8**
   - ✓ "Compile the library using D8" — AÇIK
   
2. **Experimental Functions → Aapt2**
   - ✓ "Enable Aapt2" — AÇIK (eski aapt yeni XML'leri tanımıyor)
   - ✓ "Enable build Aab/Apks" — AÇIK

3. **Experimental Functions → ViewBinding**
   - ✓ "Enable ViewBinding" — AÇIK (build.gradle.kts'de `viewBinding = true` var)

## Kapalı Kalması Gerekenler (✗)

- "Enable custom Apks signature" — Kapalı (debug imzası yeterli)
- "Configure MinApiLevel" — Kapalı (otomatik algılansın)

## Derleme Öncesi

1. Cihazdan eski FloatLauncher uygulamasını tamamen kaldır
2. AIDE'de: **Build → Clean** (cache temizle)
3. Sonra: **Build** (yeni derle)

## minSdk = 29 (Android 10)

Bu proje artık Android 10 (API 29) ile uyumlu. Manifestteki yüksek API özellikleri kaldırılmıştır.

---

E�er hâlâ hata alıyorsan:
- AIDE'deki **Gradle Project** ayarında "Gradle offline mode"'u kapattığından emin ol
- Cihaz hafızası kontrol et (AIDE derleme sırasında biraz yer gerekliyor)
