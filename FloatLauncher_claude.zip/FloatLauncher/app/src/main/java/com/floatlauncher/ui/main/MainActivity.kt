package com.floatlauncher.ui.main

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.floatlauncher.FloatLauncherApp
import com.floatlauncher.data.model.AppInfo
import com.floatlauncher.service.FloatingPanelService
import com.floatlauncher.service.FloatingWindowManager
import com.floatlauncher.service.LaunchResult
import com.floatlauncher.ui.permissions.PermissionsScreen
import com.floatlauncher.ui.permissions.PermissionsState
import com.floatlauncher.ui.theme.FloatLauncherTheme
import com.floatlauncher.util.DeviceCapabilityUtils
import com.floatlauncher.util.PermissionUtils

/**
 * Uygulamanın tek Activity'si. Tüm ekranlar Jetpack Compose ile bu Activity
 * içinde, basit bir state makinesiyle (izin ekranı ↔ ana ekran) yönetilir.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        MainViewModelFactory((application as FloatLauncherApp).appRepository)
    }

    private lateinit var floatingWindowManager: FloatingWindowManager

    // --- İzin sonuçlarını dinleyen launcher'lar ---
    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { /* state resume'da yeniden okunur */ }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* state resume'da yeniden okunur */ }

    private val accessibilitySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { /* state resume'da yeniden okunur */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        floatingWindowManager = FloatingWindowManager(this)

        setContent {
            FloatLauncherTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FloatLauncherRoot()
                }
            }
        }
    }

    @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
    @Composable
    private fun FloatLauncherRoot() {
        val context = LocalContext.current
        val lifecycleOwner = LocalLifecycleOwner.current

        var permissionsState by remember {
            mutableStateOf(PermissionsState.from(context))
        }
        var onboardingDone by rememberSaveable { mutableStateOf(false) }
        var isPanelActive by rememberSaveable { mutableStateOf(false) }

        // Activity her onResume'a geldiğinde (ör. kullanıcı Ayarlar'dan
        // döndüğünde) izin durumunu tazele.
        DisposableEffect(lifecycleOwner) {
            val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    permissionsState = PermissionsState.from(context)
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        val uiState by viewModel.uiState.collectAsState()

        AnimatedContent(
            targetState = !onboardingDone && !permissionsState.hasRequiredPermissions,
            label = "onboarding_transition"
        ) { showOnboarding ->
            if (showOnboarding) {
                PermissionsScreen(
                    state = permissionsState,
                    onRequestOverlay = {
                        overlayPermissionLauncher.launch(
                            PermissionUtils.buildOverlayPermissionIntent(context)
                        )
                    },
                    onRequestNotifications = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    onRequestAccessibility = {
                        accessibilitySettingsLauncher.launch(
                            PermissionUtils.buildAccessibilitySettingsIntent()
                        )
                    },
                    onContinue = { onboardingDone = true }
                )
            } else {
                var selectedApp by remember { mutableStateOf<AppInfo?>(null) }
                val sheetState = rememberModalBottomSheetState()

                MainScreen(
                    state = uiState,
                    onSearchQueryChange = viewModel::onSearchQueryChange,
                    onTabSelected = viewModel::onTabSelected,
                    onCategorySelected = viewModel::onCategorySelected,
                    onAppClick = { selectedApp = it },
                    onFavoriteToggle = { viewModel.toggleFavorite(it.packageName) },
                    onTogglePanel = {
                        isPanelActive = togglePanelService(isPanelActive, permissionsState)
                    },
                    isPanelActive = isPanelActive
                )

                selectedApp?.let { app ->
                    val capability = remember { DeviceCapabilityUtils.detectFloatingCapability(context) }
                    ModalBottomSheet(
                        onDismissRequest = { selectedApp = null },
                        sheetState = sheetState
                    ) {
                        com.floatlauncher.ui.main.AppDetailContent(
                            app = app,
                            capability = capability,
                            onFavoriteToggle = { viewModel.toggleFavorite(app.packageName) },
                            onLaunchFloating = {
                                launchApp(app.packageName)
                                selectedApp = null
                            },
                            onLaunchNormal = {
                                launchApp(app.packageName)
                                selectedApp = null
                            },
                            onOpenManufacturerSettings = {
                                val intents = DeviceCapabilityUtils.buildManufacturerSettingsIntentChain(context)
                                if (!DeviceCapabilityUtils.launchFirstResolvable(context, intents)) {
                                    Toast.makeText(
                                        context,
                                        "Üreticiye özgü ayar sayfası bulunamadı.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    private fun launchApp(packageName: String) {
        viewModel.recordLaunch(packageName)
        when (val result = floatingWindowManager.launch(packageName)) {
            is LaunchResult.FreeformLaunched ->
                Toast.makeText(this, "Serbest-form pencerede başlatıldı", Toast.LENGTH_SHORT).show()
            is LaunchResult.NormalLaunched ->
                Toast.makeText(this, "Uygulama normal şekilde başlatıldı", Toast.LENGTH_SHORT).show()
            is LaunchResult.UnsupportedRedirectToSettings ->
                Toast.makeText(
                    this,
                    "Bu cihaz kayan pencereyi desteklemiyor; uygulama normal başlatıldı.",
                    Toast.LENGTH_LONG
                ).show()
            is LaunchResult.Failed ->
                Toast.makeText(this, "Başlatılamadı: ${result.reason}", Toast.LENGTH_LONG).show()
        }
    }

    /** Kayan kontrol panelini açar/kapatır; overlay izni yoksa kullanıcıyı yönlendirir. */
    private fun togglePanelService(currentlyActive: Boolean, permissions: PermissionsState): Boolean {
        if (!permissions.hasOverlay) {
            Toast.makeText(
                this,
                getString(com.floatlauncher.R.string.perm_overlay_desc),
                Toast.LENGTH_LONG
            ).show()
            overlayPermissionLauncher.launch(PermissionUtils.buildOverlayPermissionIntent(this))
            return currentlyActive
        }

        return if (currentlyActive) {
            stopService(Intent(this, FloatingPanelService::class.java))
            false
        } else {
            val intent = Intent(this, FloatingPanelService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            true
        }
    }
}
