package com.floatlauncher

import android.app.Application
import com.floatlauncher.data.repository.AppRepository
import com.floatlauncher.util.PreferencesManager

/**
 * Basit, hafif bir "el yapımı DI" kapsayıcısı. Proje boyutuna göre Hilt/Koin
 * eklemek yerine, bağımlılıkların tek bir yerde açıkça kurulduğu şeffaf bir
 * yaklaşım tercih edildi (daha az boilerplate, daha düşük RAM ayak izi).
 */
class FloatLauncherApp : Application() {

    lateinit var preferencesManager: PreferencesManager
        private set

    lateinit var appRepository: AppRepository
        private set

    override fun onCreate() {
        super.onCreate()
        preferencesManager = PreferencesManager(this)
        appRepository = AppRepository(this, preferencesManager)
    }
}
