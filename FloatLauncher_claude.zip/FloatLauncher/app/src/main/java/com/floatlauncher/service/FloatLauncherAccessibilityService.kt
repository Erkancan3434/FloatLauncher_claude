package com.floatlauncher.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * TAMAMEN OPSİYONEL erişilebilirlik servisi.
 *
 * Amaç: Yalnızca hangi paketin ön planda olduğunu ve pencere durumu
 * değişikliklerini algılayarak, cihazın gerçek çoklu pencere/freeform
 * durumu hakkında UI katmanına daha isabetli geri bildirim sağlamak.
 *
 * Bu servis:
 *  - Ekran içeriğini, metni veya tuş vuruşlarını OKUMAZ
 *    (canRetrieveWindowContent="false" — bkz. accessibility_service_config.xml).
 *  - Hiçbir veriyi diske ya da ağa KAYDETMEZ/GÖNDERMEZ.
 *  - Kullanıcı istediği an Ayarlar > Erişilebilirlik'ten kapatabilir.
 *  - Uygulamanın çekirdek işlevleri (listeleme, favoriler, freeform başlatma)
 *    bu servis olmadan da tam çalışır durumdadır.
 */
class FloatLauncherAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Kasıtlı olarak boş bırakıldı: şu an için sadece servisin etkin
        // olup olmadığının tespiti (PermissionUtils.isAccessibilityServiceEnabled)
        // kullanılıyor. İleride pencere durumu event'lerinden
        // (TYPE_WINDOWS_CHANGED) türetilecek ek sinyaller buraya eklenebilir.
    }

    override fun onInterrupt() {
        // Servis kesintiye uğradığında yapılacak özel bir işlem yok.
    }
}
