package com.floatlauncher.ui.permissions

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.floatlauncher.R
import com.floatlauncher.ui.theme.AccentBlue
import com.floatlauncher.ui.theme.SuccessGreen
import com.floatlauncher.ui.theme.SurfaceVariantDark

/**
 * Kullanıcıyı sırasıyla gerekli izinlerden geçiren onboarding ekranı.
 * Her kart: açıklama + "İzin Ver/Ayarlara Git" butonu + mevcut durum ikonu.
 */
@Composable
fun PermissionsScreen(
    state: PermissionsState,
    onRequestOverlay: () -> Unit,
    onRequestNotifications: () -> Unit,
    onRequestAccessibility: () -> Unit,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            text = "İzinleri Ayarlayalım",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "FloatLauncher'ın kayan pencere özelliklerini kullanabilmesi için birkaç izne ihtiyacı var.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(24.dp))

        PermissionCard(
            icon = Icons.Filled.Visibility,
            title = stringRes(R.string.perm_overlay_title),
            description = stringRes(R.string.perm_overlay_desc),
            granted = state.hasOverlay,
            required = true,
            onAction = onRequestOverlay
        )

        Spacer(Modifier.height(16.dp))

        PermissionCard(
            icon = Icons.Filled.Notifications,
            title = stringRes(R.string.perm_notification_title),
            description = stringRes(R.string.perm_notification_desc),
            granted = state.hasNotifications,
            required = true,
            onAction = onRequestNotifications
        )

        Spacer(Modifier.height(16.dp))

        PermissionCard(
            icon = Icons.Filled.Layers,
            title = stringRes(R.string.perm_accessibility_title),
            description = stringRes(R.string.perm_accessibility_desc),
            granted = state.hasAccessibility,
            required = false,
            onAction = onRequestAccessibility
        )

        Spacer(Modifier.height(32.dp))

        Button(
            onClick = onContinue,
            enabled = state.hasRequiredPermissions,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
            Text(if (state.hasRequiredPermissions) "Devam Et" else "Önce zorunlu izinleri verin")
        }

        if (!state.hasRequiredPermissions) {
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
                Text(stringRes(R.string.skip_for_now), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PermissionCard(
    icon: ImageVector,
    title: String,
    description: String,
    granted: Boolean,
    required: Boolean,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = SurfaceVariantDark,
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                if (!required) {
                    AssistChip(
                        onClick = {},
                        enabled = false,
                        label = { Text("Opsiyonel", style = MaterialTheme.typography.labelSmall) }
                    )
                }
                Spacer(Modifier.width(8.dp))
                Icon(
                    imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (granted) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!granted) {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = onAction, modifier = Modifier.fillMaxWidth()) {
                    Text(stringRes(R.string.grant_permission))
                }
            }
        }
    }
}

@Composable
private fun stringRes(id: Int): String = androidx.compose.ui.res.stringResource(id)
