package com.floatlauncher.data.model

import android.graphics.drawable.Drawable

/**
 * Cihazda kurulu tek bir uygulamayı temsil eden değişmez (immutable) veri sınıfı.
 *
 * Bu sınıf sadece PackageManager'dan okunan meta verileri tutar; hiçbir şekilde
 * ilgili uygulamanın APK'sını, verisini veya çalışma zamanını klonlamaz/kopyalamaz.
 */
data class AppInfo(
    val packageName: String,
    val label: String,
    val icon: Drawable?,
    val isSystemApp: Boolean,
    val category: AppCategory,
    val versionName: String?,
    val installTimeMillis: Long,
    val lastUpdateTimeMillis: Long,
    val isFavorite: Boolean = false,
    val lastLaunchedMillis: Long? = null
)

/**
 * PackageManager kategori sabitlerinden türetilen basit, kullanıcı dostu kategoriler.
 */
enum class AppCategory(val displayName: String) {
    GAME("Oyun"),
    SOCIAL("Sosyal"),
    PRODUCTIVITY("Üretkenlik"),
    MEDIA("Medya"),
    COMMUNICATION("İletişim"),
    TOOLS("Araçlar"),
    SYSTEM("Sistem"),
    OTHER("Diğer")
}
