package com.floatlauncher.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val FloatLauncherDarkColors = darkColorScheme(
    primary = AccentBlue,
    onPrimary = TextPrimaryDark,
    primaryContainer = AccentBlueDark,
    onPrimaryContainer = TextPrimaryDark,
    secondary = AccentBlueLight,
    background = BackgroundDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    error = ErrorRed
)

/**
 * FloatLauncher her zaman koyu + mavi vurgulu bir tema kullanır (istenen
 * "modern dark theme with blue accents" tasarımı); bu nedenle dinamik/açık
 * temaya bilinçli olarak geçilmez.
 */
@Composable
fun FloatLauncherTheme(content: @Composable () -> Unit) {
    val colorScheme = FloatLauncherDarkColors
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FloatLauncherTypography,
        content = content
    )
}
