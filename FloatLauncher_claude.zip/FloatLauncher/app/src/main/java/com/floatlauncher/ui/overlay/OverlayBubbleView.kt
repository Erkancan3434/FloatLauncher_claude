package com.floatlauncher.ui.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Panel küçültüldüğünde ekranda kalan, sürüklenebilir tek dokunuşluk balon.
 * Bir dokunuşla panel geri yüklenir; sürükleme ile herhangi bir yere taşınabilir.
 *
 * Basit bir dokunma/sürükleme ayrımı: parmak [TAP_SLOP_PX] pikselden fazla
 * hareket ettiyse bu bir sürükleme sayılır, aksi halde tek dokunuş (tap) kabul
 * edilir ve panel geri yüklenir.
 */
class OverlayBubbleView(context: Context) : View(context) {

    companion object {
        private const val TAP_SLOP_PX = 12f
    }

    private var onDrag: ((dx: Float, dy: Float) -> Unit)? = null
    private var onTap: (() -> Unit)? = null

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var totalMovement = 0f

    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3D8BFF")
        style = Paint.Style.FILL
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private var pulseScale = 1f
    private val pulseAnimator = ValueAnimator.ofFloat(1f, 1.08f, 1f).apply {
        duration = 1600
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            pulseScale = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        pulseAnimator.start()
    }

    fun setOnBubbleDragListener(listener: (dx: Float, dy: Float) -> Unit) {
        onDrag = listener
    }

    fun setOnBubbleTapListener(listener: () -> Unit) {
        onTap = listener
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = (width.coerceAtMost(height) / 2f - 4f) * pulseScale
        canvas.drawCircle(cx, cy, radius, bubblePaint)
        // Basit "F" harfi yerine küçük daire+halka ikonu (marka simgesi yer tutucu)
        canvas.drawCircle(cx, cy, radius * 0.35f, iconPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                lastX = event.rawX
                lastY = event.rawY
                totalMovement = 0f
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastX
                val dy = event.rawY - lastY
                totalMovement += hypot(abs(dx), abs(dy))
                onDrag?.invoke(dx, dy)
                lastX = event.rawX
                lastY = event.rawY
            }
            MotionEvent.ACTION_UP -> {
                if (totalMovement < TAP_SLOP_PX) {
                    onTap?.invoke()
                }
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        pulseAnimator.cancel()
        super.onDetachedFromWindow()
    }
}
