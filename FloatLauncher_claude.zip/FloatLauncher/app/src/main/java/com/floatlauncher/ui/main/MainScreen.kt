package com.floatlauncher.ui.main

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.filled.WidgetsOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.floatlauncher.R
import com.floatlauncher.data.model.AppInfo
import com.floatlauncher.ui.components.AppGrid
import com.floatlauncher.ui.components.AppSearchBar
import com.floatlauncher.ui.components.CategoryFilterRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    state: MainUiState,
    onSearchQueryChange: (String) -> Unit,
    onTabSelected: (AppListTab) -> Unit,
    onCategorySelected: (com.floatlauncher.data.model.AppCategory?) -> Unit,
    onAppClick: (AppInfo) -> Unit,
    onFavoriteToggle: (AppInfo) -> Unit,
    onTogglePanel: () -> Unit,
    isPanelActive: Boolean,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onTogglePanel,
                icon = {
                    Icon(
                        if (isPanelActive) Icons.Filled.WidgetsOff else Icons.Filled.Widgets,
                        contentDescription = null
                    )
                },
                text = { Text(if (isPanelActive) "Paneli Kapat" else "Kayan Paneli Aç") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize()
        ) {
            Spacer(Modifier.height(8.dp))
            AppSearchBar(query = state.searchQuery, onQueryChange = onSearchQueryChange)
            Spacer(Modifier.height(12.dp))

            TabRow(
                selectedTabIndex = state.selectedTab.ordinal,
                containerColor = androidx.compose.ui.graphics.Color.Transparent
            ) {
                Tab(
                    selected = state.selectedTab == AppListTab.ALL,
                    onClick = { onTabSelected(AppListTab.ALL) },
                    text = { Text(stringResource(R.string.tab_all)) }
                )
                Tab(
                    selected = state.selectedTab == AppListTab.FAVORITES,
                    onClick = { onTabSelected(AppListTab.FAVORITES) },
                    text = { Text(stringResource(R.string.tab_favorites)) }
                )
                Tab(
                    selected = state.selectedTab == AppListTab.RECENT,
                    onClick = { onTabSelected(AppListTab.RECENT) },
                    text = { Text(stringResource(R.string.tab_recent)) }
                )
            }

            Spacer(Modifier.height(12.dp))
            CategoryFilterRow(selected = state.selectedCategory, onSelect = onCategorySelected)
            Spacer(Modifier.height(12.dp))

            when {
                state.isLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator()
                            Spacer(Modifier.height(12.dp))
                            Text(stringResource(R.string.loading_apps))
                        }
                    }
                }
                state.apps.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            stringResource(R.string.no_apps_found),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                else -> {
                    AppGrid(
                        apps = state.apps,
                        onAppClick = onAppClick,
                        onFavoriteToggle = onFavoriteToggle,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
