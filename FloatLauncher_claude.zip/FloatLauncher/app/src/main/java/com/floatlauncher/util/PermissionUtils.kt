package com.floatlauncher.util

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityManager
import com.floatlauncher.service.FloatLauncherAccessibilityService

/**
 * Uygulamanın ihtiyaç duyduğu tüm izinlerin (overlay, bildirim, erişilebilirlik)
 * durumunu kontrol eden ve kullanıcıyı doğru Ayarlar sayfasına yönlendiren
 * merkezi yardımcı obje.
 */
object PermissionUtils {

    /** "Diğer uygulamaların üzerinde göster" (SYSTEM_ALERT_WINDOW) izni var mı? */
    fun hasOverlayPermission(context: Context): Boolean =
        Settings.canDrawOverlays(context)

    /** Kullanıcıyı doğrudan bu uygulama için overlay izin sayfasına götürür. */
    fun buildOverlayPermissionIntent(context: Context): Intent =
        Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )

    /** Android 13+ için çalışma zamanı bildirim izni gerekip gerekmediği. */
    fun requiresNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    /**
     * FloatLauncherAccessibilityService'in kullanıcı tarafından etkinleştirilip
     * etkinleştirilmediğini kontrol eder. Bu servis TAMAMEN opsiyoneldir;
     * uygulama bu izin olmadan da (freeform destekli cihazlarda) çalışabilir.
     */
    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedComponent = "${context.packageName}/${FloatLauncherAccessibilityService::class.java.canonicalName}"

        val enabledServicesSetting = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServicesSetting)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expectedComponent, ignoreCase = true)) return true
        }
        return false
    }

    /** Kullanıcıyı sistem Erişilebilirlik ayarları sayfasına götürür. */
    fun buildAccessibilitySettingsIntent(): Intent =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)

    /** Uygulamanın kendi ayrıntı sayfasına (izinleri elle vermesi gerekirse) yönlendirir. */
    fun buildAppSettingsIntent(context: Context): Intent =
        Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${context.packageName}")
        )
}
