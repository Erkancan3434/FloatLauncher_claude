package com.floatlauncher.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.floatlauncher.R
import com.floatlauncher.ui.main.MainActivity
import com.floatlauncher.ui.overlay.OverlayPanelView
import kotlin.math.abs
import kotlin.math.max

/**
 * Diğer uygulamaların üzerinde çizilen (TYPE_APPLICATION_OVERLAY) ImGui
 * esintili kontrol panelini yöneten ön plan servisi.
 *
 * Sorumlulukları:
 *  - Paneli WindowManager ile ekrana eklemek/kaldırmak.
 *  - Sürükleme (drag), kenarlardan yeniden boyutlandırma (resize) ve
 *    balona küçültme/geri yükleme dokunuş olaylarını yönetmek.
 *  - Android kuralı gereği zorunlu olan kalıcı bildirimi göstermek.
 *
 * NOT: Bu servis SADECE FloatLauncher'ın kendi UI'ını (panel/balon) ekrana
 * çizer. Başka bir uygulamanın arayüzünü asla bu panelin içine gömmez;
 * "kayan pencerede başlat" özelliği ayrı olarak [FloatingWindowManager]
 * üzerinden, hedef uygulamanın KENDİ Activity'sini resmi API'lerle
 * başlatarak çalışır.
 */
class FloatingPanelService : Service() {

    companion object {
        const val CHANNEL_ID = "floating_panel_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.floatlauncher.action.STOP_PANEL"

        const val MIN_PANEL_WIDTH_DP = 220
        const val MIN_PANEL_HEIGHT_DP = 160
    }

    private lateinit var windowManager: WindowManager
    private var panelView: OverlayPanelView? = null
    private var bubbleView: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var isMinimized = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())

        if (panelView == null) {
            addPanel()
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, FloatingPanelService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_panel)
            .setContentTitle(getString(R.string.notif_content_title))
            .setContentText(getString(R.string.notif_content_text))
            .setContentIntent(contentIntent)
            .addAction(0, getString(R.string.panel_close), stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    // ---------------------------------------------------------------------
    // Panel ekleme / kaldırma
    // ---------------------------------------------------------------------

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun addPanel() {
        val density = resources.displayMetrics.density
        val defaultWidth = (280 * density).toInt()
        val defaultHeight = (380 * density).toInt()

        val params = WindowManager.LayoutParams(
            defaultWidth,
            defaultHeight,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 60
            y = 200
        }
        panelParams = params

        val view = OverlayPanelView(
            context = this,
            onDrag = { dx, dy -> moveWindow(params, dx, dy) },
            onResize = { dw, dh -> resizeWindow(params, density, dw, dh) },
            onMinimize = { minimizeToBubble() },
            onClose = { stopSelf() }
        )
        panelView = view
        windowManager.addView(view, params)
    }

    private fun moveWindow(params: WindowManager.LayoutParams, dx: Float, dy: Float) {
        params.x += dx.toInt()
        params.y += dy.toInt()
        panelView?.let { safeUpdateViewLayout(it, params) }
    }

    private fun resizeWindow(params: WindowManager.LayoutParams, density: Float, dw: Float, dh: Float) {
        val minWidthPx = (MIN_PANEL_WIDTH_DP * density).toInt()
        val minHeightPx = (MIN_PANEL_HEIGHT_DP * density).toInt()
        params.width = max(minWidthPx, params.width + dw.toInt())
        params.height = max(minHeightPx, params.height + dh.toInt())
        panelView?.let { safeUpdateViewLayout(it, params) }
    }

    private fun safeUpdateViewLayout(view: View, params: WindowManager.LayoutParams) {
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: IllegalArgumentException) {
            // View henüz eklenmemiş veya zaten kaldırılmış olabilir; sessizce yut.
        }
    }

    // ---------------------------------------------------------------------
    // Balona küçültme / geri yükleme
    // ---------------------------------------------------------------------

    private fun minimizeToBubble() {
        if (isMinimized) return
        isMinimized = true

        panelView?.let { windowManager.removeView(it) }

        val density = resources.displayMetrics.density
        val bubbleSize = (56 * density).toInt()

        val params = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = panelParams?.x ?: 60
            y = panelParams?.y ?: 200
        }
        bubbleParams = params

        val bubble = com.floatlauncher.ui.overlay.OverlayBubbleView(this).apply {
            setOnBubbleDragListener { dx, dy ->
                params.x += dx.toInt()
                params.y += dy.toInt()
                safeUpdateViewLayout(this, params)
            }
            setOnBubbleTapListener { restoreFromBubble() }
        }
        bubbleView = bubble
        windowManager.addView(bubble, params)
    }

    private fun restoreFromBubble() {
        if (!isMinimized) return
        isMinimized = false

        bubbleView?.let { windowManager.removeView(it) }
        bubbleView = null
        addPanel()
    }

    override fun onDestroy() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        bubbleView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
