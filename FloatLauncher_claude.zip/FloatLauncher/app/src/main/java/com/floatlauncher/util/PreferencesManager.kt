package com.floatlauncher.util

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "floatlauncher_prefs")

/**
 * Favori uygulamaları ve son kullanılan uygulamaların zaman damgalarını
 * Jetpack DataStore üzerinde kalıcı olarak saklayan basit anahtar-değer katmanı.
 *
 * "packageName:timestamp" formatında string set kullanılarak hem sade hem de
 * ekstra bağımlılık gerektirmeyen bir çözüm tercih edildi.
 */
class PreferencesManager(private val context: Context) {

    private object Keys {
        val FAVORITES = stringSetPreferencesKey("favorites")
        val RECENTS = stringSetPreferencesKey("recents") // "packageName|timestamp"
    }

    val favoritesFlow: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[Keys.FAVORITES] ?: emptySet()
    }

    val recentAppsFlow: Flow<Map<String, Long>> = context.dataStore.data.map { prefs ->
        (prefs[Keys.RECENTS] ?: emptySet()).mapNotNull { entry ->
            val parts = entry.split("|")
            if (parts.size == 2) parts[0] to (parts[1].toLongOrNull() ?: 0L) else null
        }.toMap()
    }

    suspend fun toggleFavorite(packageName: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.FAVORITES] ?: emptySet()
            prefs[Keys.FAVORITES] = if (packageName in current) {
                current - packageName
            } else {
                current + packageName
            }
        }
    }

    suspend fun recordRecentLaunch(packageName: String) {
        context.dataStore.edit { prefs ->
            val current = (prefs[Keys.RECENTS] ?: emptySet())
                .mapNotNull { entry ->
                    val parts = entry.split("|")
                    if (parts.size == 2) parts[0] to (parts[1].toLongOrNull() ?: 0L) else null
                }.toMap().toMutableMap()

            current[packageName] = System.currentTimeMillis()

            // Sadece en son 30 uygulamayı tut, DataStore'un şişmesini önle.
            val trimmed = current.entries
                .sortedByDescending { it.value }
                .take(30)
                .associate { it.key to it.value }

            prefs[Keys.RECENTS] = trimmed.map { "${it.key}|${it.value}" }.toSet()
        }
    }
}
