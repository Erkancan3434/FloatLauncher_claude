package com.floatlauncher.util

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/**
 * Cihazın gerçek pencere yeteneklerini SAHTE değil, RESMİ Android API'leri
 * üzerinden tespit eden sınıf.
 *
 * ÖNEMLİ / DÜRÜST NOT:
 * Android, üçüncü taraf (root olmayan) bir uygulamanın BAŞKA bir uygulamayı
 * kendi çizdiği bir overlay penceresinin İÇİNE gömmesine izin vermez. Bu,
 * ancak şu üç yoldan biriyle "gerçek" anlamda mümkün olur:
 *   1) Cihaz resmi olarak FEATURE_FREEFORM_WINDOW_MANAGEMENT destekliyorsa
 *      (bazı tabletler, Samsung DeX, Android Studio emülatöründeki
 *      geliştirici ayarlarıyla açılan freeform) → ActivityOptions.setLaunchBounds()
 *      ile hedef uygulama serbest-form bir pencerede başlatılabilir.
 *   2) Üretici (Samsung, Xiaomi/MIUI, vb.) kendi çoklu-pencere/"Pop-up View"
 *      özelliğine sahip bir Ayarlar sayfası sağlıyorsa → kullanıcı oraya
 *      yönlendirilir; uygulama bu özelliği programatik olarak tetikleyemez,
 *      çünkü bu üreticilerin genel geliştiricilere açık bir API'si yoktur.
 *   3) Cihaz root'luysa → bu proje kapsamı dışıdır (kasıtlı olarak
 *      desteklenmez, çünkü kullanıcıyı güvenlik riskine sokar).
 *
 * Bu sınıf, hangi yolun mevcut olduğunu tespit eder ve UI katmanına doğru
 * seçeneği sunar. Desteklenmeyen bir cihazda ASLA sahte/kırık bir deneyim
 * sunulmaz; kullanıcıya açıkça bilgi verilip ilgili ayarlara yönlendirilir.
 */
object DeviceCapabilityUtils {

    enum class FloatingCapability {
        /** Cihaz resmi freeform pencere yönetimini destekliyor. */
        NATIVE_FREEFORM,

        /** Cihaz üreticiye özgü bir çoklu pencere/pop-up özelliğine sahip olabilir. */
        MANUFACTURER_SPECIFIC,

        /** Hiçbir resmi kayan pencere yolu tespit edilemedi. */
        UNSUPPORTED
    }

    /** Bilinen, çoklu pencere/pop-up özelliğine sahip üreticiler. */
    private val KNOWN_MULTIWINDOW_MANUFACTURERS = setOf(
        "samsung", "xiaomi", "redmi", "oppo", "vivo", "realme", "oneplus", "huawei"
    )

    fun manufacturer(): String = Build.MANUFACTURER.lowercase()

    fun isKnownMultiWindowManufacturer(): Boolean =
        manufacturer() in KNOWN_MULTIWINDOW_MANUFACTURERS

    /** Cihazın resmi olarak freeform pencere yönetimini destekleyip desteklemediği. */
    fun supportsNativeFreeform(context: Context): Boolean {
        val pm = context.packageManager
        val hasFeature = pm.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)

        // Bazı cihazlarda özellik bayrağı yerine geliştirici ayarındaki
        // "force_resizable_activities" / "enable_freeform_support" bayrağı
        // ile de freeform açılabilir (özellikle geliştirici modunda).
        val forceResizable = try {
            Settings.Global.getInt(context.contentResolver, "force_resizable_activities", 0) == 1
        } catch (e: Exception) {
            false
        }
        val enabledFreeformSetting = try {
            Settings.Global.getInt(context.contentResolver, "enable_freeform_support", 0) == 1
        } catch (e: Exception) {
            false
        }

        return hasFeature || forceResizable || enabledFreeformSetting
    }

    /** Cihazda çoklu pencere (split-screen / picture-in-picture) desteği var mı? */
    fun supportsMultiWindow(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        return am?.isLowRamDevice?.not() == true &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
    }

    /** Genel kayan pencere yeteneği sınıflandırması. */
    fun detectFloatingCapability(context: Context): FloatingCapability = when {
        supportsNativeFreeform(context) -> FloatingCapability.NATIVE_FREEFORM
        isKnownMultiWindowManufacturer() -> FloatingCapability.MANUFACTURER_SPECIFIC
        else -> FloatingCapability.UNSUPPORTED
    }

    /**
     * Üreticiye özgü çoklu pencere/pop-up ayarlarını açmayı DENER.
     * Bu Intent'ler resmi olarak dokümante edilmemiştir ve cihaz/ROM sürümüne
     * göre değişebilir; bu yüzden her zaman genel Ayarlar sayfasına düşen
     * (fallback) bir zincir olarak tasarlanmıştır. Uygulama hiçbir zaman
     * bu Intent'lerin kesin çalışacağını varsaymaz.
     */
    fun buildManufacturerSettingsIntentChain(context: Context): List<Intent> {
        val candidates = mutableListOf<Intent>()
        when (manufacturer()) {
            "samsung" -> {
                candidates += Intent("com.samsung.android.sm.ACTION_MULTI_WINDOW_SETTINGS")
                candidates += Intent("android.settings.MULTI_WINDOW_SETTINGS")
            }
            "xiaomi", "redmi" -> {
                candidates += Intent().apply {
                    component = android.content.ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.settings.PermissionMainActivity"
                    )
                }
            }
            "oppo", "realme" -> {
                candidates += Intent().apply {
                    component = android.content.ComponentName(
                        "com.coloros.floatassistant",
                        "com.coloros.floatassistant.MainActivity"
                    )
                }
            }
            "vivo" -> {
                candidates += Intent().apply {
                    component = android.content.ComponentName(
                        "com.vivo.abe",
                        "com.vivo.applicationbehaviorengine.ui.ExcessivePowerManagerActivity"
                    )
                }
            }
        }
        // Her durumda son çare: uygulamanın genel ayar sayfası.
        candidates += PermissionUtils.buildAppSettingsIntent(context)
        return candidates
    }

    /**
     * Verilen Intent listesinden ilk çalışabilir (resolve edilebilir) olanı
     * başlatır. Hiçbiri çalışmazsa false döner ve UI katmanı kullanıcıyı
     * bilgilendirir.
     */
    fun launchFirstResolvable(context: Context, intents: List<Intent>): Boolean {
        for (intent in intents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                return true
            }
        }
        return false
    }
}
