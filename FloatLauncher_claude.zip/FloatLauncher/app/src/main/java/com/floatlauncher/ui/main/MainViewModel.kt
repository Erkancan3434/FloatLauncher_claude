package com.floatlauncher.ui.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.floatlauncher.data.model.AppCategory
import com.floatlauncher.data.model.AppInfo
import com.floatlauncher.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppListTab { ALL, FAVORITES, RECENT }

private data class FilterState(
    val query: String,
    val tab: AppListTab,
    val category: AppCategory?,
    val loading: Boolean,
    val selected: AppInfo?
)

data class MainUiState(
    val isLoading: Boolean = true,
    val searchQuery: String = "",
    val selectedTab: AppListTab = AppListTab.ALL,
    val selectedCategory: AppCategory? = null,
    val apps: List<AppInfo> = emptyList(),
    val selectedApp: AppInfo? = null
)

/**
 * Uygulama listesi ekranının tüm state'ini ve iş mantığını yöneten ViewModel.
 * Ağır PackageManager taraması bir kez yapılır; favoriler/son kullanılanlar
 * ise DataStore Flow'ları üzerinden reaktif olarak birleştirilir.
 */
class MainViewModel(private val repository: AppRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _selectedTab = MutableStateFlow(AppListTab.ALL)
    private val _selectedCategory = MutableStateFlow<AppCategory?>(null)
    private val _isLoading = MutableStateFlow(true)
    private val _selectedApp = MutableStateFlow<AppInfo?>(null)
    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())

    init {
        viewModelScope.launch {
            _isLoading.value = true
            val apps = repository.getInstalledApps()
            _allApps.value = apps
            _isLoading.value = false
        }
    }

    private val enrichedApps: kotlinx.coroutines.flow.Flow<List<AppInfo>> =
        _allApps.combine(repository.favoritesFlow()) { apps, favorites ->
            apps to favorites
        }.combine(repository.recentAppsFlow()) { (apps, favorites), recents ->
            apps.map { app ->
                app.copy(
                    isFavorite = favorites.contains(app.packageName),
                    lastLaunchedMillis = recents[app.packageName]
                )
            }
        }

    // kotlinx.coroutines.flow.combine'ın tip-parametreli overload'ları en fazla
    // 5 farklı Flow<T> tipini destekler; 6 farklı tipte akışı güvenli şekilde
    // birleştirmek için iç içe (nested) combine kullanılıyor.
    private val filterState = combine(
        _searchQuery, _selectedTab, _selectedCategory, _isLoading, _selectedApp
    ) { query, tab, category, loading, selected ->
        FilterState(query, tab, category, loading, selected)
    }

    val uiState: StateFlow<MainUiState> = combine(
        enrichedApps, filterState
    ) { apps, filter ->
        val query = filter.query
        val tab = filter.tab
        val category = filter.category
        val loading = filter.loading
        val selected = filter.selected

        val filtered = apps
            .filter { app ->
                query.isBlank() || app.label.contains(query, ignoreCase = true)
            }
            .filter { app ->
                category == null || app.category == category
            }
            .let { list ->
                when (tab) {
                    AppListTab.ALL -> list
                    AppListTab.FAVORITES -> list.filter { it.isFavorite }
                    AppListTab.RECENT -> list
                        .filter { it.lastLaunchedMillis != null }
                        .sortedByDescending { it.lastLaunchedMillis }
                }
            }

        MainUiState(
            isLoading = loading,
            searchQuery = query,
            selectedTab = tab,
            selectedCategory = category,
            apps = filtered,
            selectedApp = selected
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MainUiState())

    fun onSearchQueryChange(query: String) { _searchQuery.value = query }
    fun onTabSelected(tab: AppListTab) { _selectedTab.value = tab }
    fun onCategorySelected(category: AppCategory?) { _selectedCategory.value = category }
    fun onAppSelected(app: AppInfo?) { _selectedApp.value = app }

    fun toggleFavorite(packageName: String) {
        viewModelScope.launch { repository.toggleFavorite(packageName) }
    }

    fun recordLaunch(packageName: String) {
        viewModelScope.launch { repository.recordLaunch(packageName) }
    }
}
