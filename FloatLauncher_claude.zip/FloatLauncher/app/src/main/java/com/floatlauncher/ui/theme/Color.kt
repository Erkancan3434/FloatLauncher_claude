package com.floatlauncher.ui.theme

import androidx.compose.ui.graphics.Color

// Koyu tema + mavi vurgu paleti — modern, cam benzeri görünüm için tasarlandı.
val BackgroundDark = Color(0xFF0B0F14)
val SurfaceDark = Color(0xFF141A21)
val SurfaceVariantDark = Color(0xFF1C242D)

val AccentBlue = Color(0xFF3D8BFF)
val AccentBlueLight = Color(0xFF6FA8FF)
val AccentBlueDark = Color(0xFF1E5FCC)

val TextPrimaryDark = Color(0xFFF2F5F8)
val TextSecondaryDark = Color(0xFF9AA6B2)

val ErrorRed = Color(0xFFFF5A5F)
val SuccessGreen = Color(0xFF39D98A)

val GlassSurface = Color(0x332C3A47)
