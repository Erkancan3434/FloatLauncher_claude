# Minimal ProGuard rules - debug build için
# Release build'de bile gerekli değildir çoğu zaman

# FloatLauncher sınıfları
-keep class com.floatlauncher.** { *; }

# Kotlin metadata
-keep class kotlin.Metadata { *; }
-keepattributes *Annotation*,Signature

# Çoklu referensleme sorunlarını çöz
-dontwarn androidx.**
-dontwarn kotlin.**
-dontwarn kotlinx.**
-dontwarn com.google.**
-dontwarn com.android.**
