package com.floatlauncher.ui.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.view.setPadding
import com.floatlauncher.R

/**
 * ImGui esintili kayan kontrol paneli.
 *
 * Özellikler:
 *  - Üst çubuktan (header) sürükleyerek taşıma.
 *  - Sağ-alt köşedeki tutamaçtan (handle) her yönde yeniden boyutlandırma.
 *  - Küçült (balon) ve kapat butonları.
 *  - Yuvarlatılmış köşeler + yarı saydam "cam" arka plan (API 31+ gerçek blur,
 *    daha eski sürümlerde zarif bir alfa katmanıyla taklit edilir).
 *  - Açılış/kapanış için basit ölçek + alfa animasyonu.
 *
 * Bu View SADECE FloatLauncher'ın kendi kontrollerini barındırır; herhangi
 * bir üçüncü taraf uygulamanın arayüzünü içermez.
 */
class OverlayPanelView(
    context: Context,
    private val onDrag: (dx: Float, dy: Float) -> Unit,
    private val onResize: (dw: Float, dh: Float) -> Unit,
    private val onMinimize: () -> Unit,
    private val onClose: () -> Unit
) : FrameLayout(context) {

    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var isDraggingHeader = false
    private var isResizing = false

    private val resizeHandleSizePx = (28 * resources.displayMetrics.density)

    init {
        setWillNotDraw(false)
        setPadding((4 * resources.displayMetrics.density).toInt())
        applyGlassBackground()
        buildContent()
        animateIn()
    }

    private fun applyGlassBackground() {
        background = GlassPanelDrawable(
            fillColor = Color.parseColor("#E6141A21"),
            borderColor = Color.parseColor("#403D8BFF"),
            cornerRadiusPx = 24 * resources.displayMetrics.density
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Gerçek arka plan bulanıklığı yalnızca Android 12+ üzerinde
            // RenderEffect ile desteklenir; eski sürümlerde yarı saydam
            // dolgu rengi zaten "cam" hissini verir.
            setRenderEffect(RenderEffect.createBlurEffect(2f, 2f, Shader.TileMode.CLAMP))
        }
    }

    private fun buildContent() {
        val density = resources.displayMetrics.density

        // --- Üst başlık çubuğu: sürükleme burada algılanır ---
        val header = FrameLayout(context).apply {
            id = View.generateViewId()
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, (44 * density).toInt())
        }
        val title = TextView(context).apply {
            text = context.getString(com.floatlauncher.R.string.app_name)
            setTextColor(Color.parseColor("#F2F5F8"))
            textSize = 14f
            setPadding((12 * density).toInt(), 0, 0, 0)
            gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.START
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT)
        }
        header.addView(title)

        val minimizeBtn = ImageButton(context).apply {
            setImageResource(android.R.drawable.arrow_down_float)
            background = null
            setColorFilterCompat(Color.parseColor("#9AA6B2"))
            layoutParams = LayoutParams((36 * density).toInt(), (36 * density).toInt()).apply {
                gravity = android.view.Gravity.END or android.view.Gravity.CENTER_VERTICAL
                marginEnd = (44 * density).toInt()
            }
            setOnClickListener { onMinimize() }
        }
        header.addView(minimizeBtn)

        val closeBtn = ImageButton(context).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            background = null
            setColorFilterCompat(Color.parseColor("#FF5A5F"))
            layoutParams = LayoutParams((36 * density).toInt(), (36 * density).toInt()).apply {
                gravity = android.view.Gravity.END or android.view.Gravity.CENTER_VERTICAL
                marginEnd = (4 * density).toInt()
            }
            setOnClickListener { onClose() }
        }
        header.addView(closeBtn)

        header.setOnTouchListener { _, event -> handleHeaderTouch(event) }
        addView(header)

        // --- İçerik alanı (kısayollar / bilgi metni) ---
        val body = TextView(context).apply {
            text = "Kayan Panel\nSürükleyerek taşı • Köşeden boyutlandır"
            setTextColor(Color.parseColor("#9AA6B2"))
            textSize = 12f
            setPadding((12 * density).toInt(), (8 * density).toInt(), (12 * density).toInt(), 0)
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = (44 * density).toInt()
            }
        }
        addView(body)

        // --- Sağ-alt yeniden boyutlandırma tutamacı ---
        val resizeHandle = View(context).apply {
            layoutParams = LayoutParams(resizeHandleSizePx.toInt(), resizeHandleSizePx.toInt()).apply {
                gravity = android.view.Gravity.END or android.view.Gravity.BOTTOM
            }
            background = ResizeHandleDrawable()
        }
        resizeHandle.setOnTouchListener { _, event -> handleResizeTouch(event) }
        addView(resizeHandle)
    }

    private fun ImageButton.setColorFilterCompat(color: Int) {
        setColorFilter(color)
    }

    private fun handleHeaderTouch(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.rawX
                lastTouchY = event.rawY
                isDraggingHeader = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDraggingHeader) {
                    val dx = event.rawX - lastTouchX
                    val dy = event.rawY - lastTouchY
                    onDrag(dx, dy)
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDraggingHeader = false
            }
        }
        return true
    }

    private fun handleResizeTouch(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.rawX
                lastTouchY = event.rawY
                isResizing = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isResizing) {
                    val dw = event.rawX - lastTouchX
                    val dh = event.rawY - lastTouchY
                    onResize(dw, dh)
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isResizing = false
            }
        }
        return true
    }

    /** Panel ilk gösterildiğinde yumuşak bir ölçek + solma animasyonu oynatır. */
    private fun animateIn() {
        scaleX = 0.85f
        scaleY = 0.85f
        alpha = 0f
        animate()
            .scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(220)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }
}

/**
 * Yuvarlatılmış köşeli, ince mavi kenarlıklı "cam" panel arka planı.
 */
private class GlassPanelDrawable(
    private val fillColor: Int,
    private val borderColor: Int,
    private val cornerRadiusPx: Float
) : android.graphics.drawable.Drawable() {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = fillColor
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = borderColor
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    override fun draw(canvas: Canvas) {
        val rect = RectF(bounds)
        rect.inset(1.5f, 1.5f)
        canvas.drawRoundRect(rect, cornerRadiusPx, cornerRadiusPx, fillPaint)
        canvas.drawRoundRect(rect, cornerRadiusPx, cornerRadiusPx, strokePaint)
    }

    override fun setAlpha(alpha: Int) { fillPaint.alpha = alpha }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        fillPaint.colorFilter = colorFilter
    }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

private class ResizeHandleDrawable : android.graphics.drawable.Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6FA8FF")
        style = Paint.Style.FILL
    }

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        // Üç küçük çizgi ile "resize" ipucu (sağ-alt köşe çentiği)
        val dotRadius = w * 0.06f
        var offset = w * 0.3f
        repeat(3) { i ->
            canvas.drawCircle(w - offset, h - (w * 0.3f), dotRadius, paint)
            canvas.drawCircle(w - (w * 0.3f), h - offset, dotRadius, paint)
            offset += w * 0.22f * (i + 1) * 0f // yer tutucu, tekil desen yeterli
        }
        canvas.drawCircle(w - w * 0.3f, h - h * 0.3f, dotRadius, paint)
        canvas.drawCircle(w - w * 0.55f, h - h * 0.3f, dotRadius, paint)
        canvas.drawCircle(w - w * 0.3f, h - h * 0.55f, dotRadius, paint)
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        paint.colorFilter = colorFilter
    }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

private typealias PixelFormat = android.graphics.PixelFormat
