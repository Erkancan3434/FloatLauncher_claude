package com.floatlauncher.data.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.floatlauncher.data.model.AppCategory
import com.floatlauncher.data.model.AppInfo
import com.floatlauncher.util.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/**
 * Cihazdaki kurulu uygulamaları PackageManager üzerinden okuyan tek veri kaynağı.
 *
 * ÖNEMLİ: Bu sınıf hiçbir uygulamanın APK dosyasını kopyalamaz, sanallaştırmaz
 * veya ikinci bir örneğini oluşturmaz. Sadece resmi Android API'leri
 * (PackageManager.getInstalledApplications, launchIntentForPackage vb.)
 * aracılığıyla listeleme ve normal başlatma (launch) işlemi yapar.
 */
class AppRepository(
    private val context: Context,
    private val preferencesManager: PreferencesManager
) {
    private val packageManager: PackageManager = context.packageManager

    /**
     * Başlatılabilir (bir launcher intent'i olan) tüm kurulu uygulamaları döndürür.
     * Ağır PackageManager çağrıları IO dispatcher'da çalıştırılır.
     */
    suspend fun getInstalledApps(includeSystemApps: Boolean = false): List<AppInfo> =
        withContext(Dispatchers.IO) {
            val flags = PackageManager.GET_META_DATA
            val installedApps = packageManager.getInstalledApplications(flags)

            installedApps
                .asSequence()
                .filter { appInfo ->
                    // Sadece kullanıcının başlatabileceği bir "launcher" ekranı
                    // olan uygulamaları göster (arka plan servisleri/kütüphaneleri hariç tut).
                    packageManager.getLaunchIntentForPackage(appInfo.packageName) != null
                }
                .filter { appInfo ->
                    includeSystemApps || !isSystemApp(appInfo)
                }
                .map { appInfo -> appInfo.toAppInfoModel() }
                .sortedBy { it.label.lowercase() }
                .toList()
        }

    private fun isSystemApp(appInfo: ApplicationInfo): Boolean =
        (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

    private fun ApplicationInfo.toAppInfoModel(): AppInfo {
        val packageInfo = try {
            packageManager.getPackageInfo(packageName, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
        return AppInfo(
            packageName = packageName,
            label = packageManager.getApplicationLabel(this).toString(),
            icon = try {
                packageManager.getApplicationIcon(this)
            } catch (e: PackageManager.NameNotFoundException) {
                null
            },
            isSystemApp = isSystemApp(this),
            category = mapCategory(category),
            versionName = packageInfo?.versionName,
            installTimeMillis = packageInfo?.firstInstallTime ?: 0L,
            lastUpdateTimeMillis = packageInfo?.lastUpdateTime ?: 0L
        )
    }

    private fun mapCategory(categoryConst: Int): AppCategory = when (categoryConst) {
        ApplicationInfo.CATEGORY_GAME -> AppCategory.GAME
        ApplicationInfo.CATEGORY_SOCIAL -> AppCategory.SOCIAL
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> AppCategory.PRODUCTIVITY
        ApplicationInfo.CATEGORY_AUDIO,
        ApplicationInfo.CATEGORY_VIDEO,
        ApplicationInfo.CATEGORY_IMAGE -> AppCategory.MEDIA
        ApplicationInfo.CATEGORY_NEWS -> AppCategory.OTHER
        else -> AppCategory.TOOLS
    }

    /** Favori paket isimleri akışı (DataStore'dan). */
    fun favoritesFlow(): Flow<Set<String>> = preferencesManager.favoritesFlow

    /** Son kullanılan paketler → son başlatma zamanı eşlemesi akışı. */
    fun recentAppsFlow(): Flow<Map<String, Long>> = preferencesManager.recentAppsFlow

    /**
     * Kurulu uygulama listesini favori/son-kullanım bilgisiyle zenginleştirilmiş
     * biçimde birleştiren yardımcı akış.
     */
    fun enrichedApps(baseApps: List<AppInfo>): Flow<List<AppInfo>> =
        combine(favoritesFlow(), recentAppsFlow()) { favorites, recents ->
            baseApps.map { app ->
                app.copy(
                    isFavorite = favorites.contains(app.packageName),
                    lastLaunchedMillis = recents[app.packageName]
                )
            }
        }

    suspend fun toggleFavorite(packageName: String) =
        preferencesManager.toggleFavorite(packageName)

    suspend fun recordLaunch(packageName: String) =
        preferencesManager.recordRecentLaunch(packageName)
}
